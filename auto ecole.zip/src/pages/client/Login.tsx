import { useState, type FormEvent } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/useAuth';
import { phoneToEmail } from '@/lib/phoneAuth';

export default function Login() {
    const { isAuthenticated, isAdmin, loading } = useAuth();
    const [telephone, setTelephone] = useState('');
    const [pin, setPin] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    if (loading) return null;
    if (isAdmin) return <Navigate to="/admin" replace />;
    if (isAuthenticated) return <Navigate to="/mon-compte" replace />;

    async function handleSubmit(e: FormEvent) {
        e.preventDefault();
        setError(null);
        setSubmitting(true);
        const { error } = await supabase.auth.signInWithPassword({
            email: phoneToEmail(telephone),
            password: pin,
        });
        setSubmitting(false);
        if (error) setError('Téléphone ou code secret incorrect.');
    }

    return (
        <div className="flex min-h-screen items-center justify-center bg-pacifique-offwhite px-4">
            <form onSubmit={handleSubmit} className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-lg">
                <h1 className="mb-6 text-xl font-semibold text-pacifique-navy-900">Connexion</h1>

                <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">Téléphone</label>
                <input
                    type="tel"
                    value={telephone}
                    onChange={(e) => setTelephone(e.target.value)}
                    required
                    placeholder="Ex: 6 99 00 00 00"
                    className="mb-4 w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                />

                <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">Code secret</label>
                <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]{6}"
                    maxLength={6}
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                    required
                    placeholder="••••••"
                    className="mb-4 w-full rounded-lg border border-gray-300 px-3 py-2 tracking-widest outline-none focus:border-pacifique-blue-500"
                />

                {error && <p className="mb-4 text-sm text-pacifique-red-500">{error}</p>}

                <button
                    type="submit"
                    disabled={submitting}
                    className="w-full rounded-lg bg-pacifique-navy-900 py-2.5 font-medium text-white transition hover:bg-pacifique-navy-700 disabled:opacity-60"
                >
                    {submitting ? 'Connexion...' : 'Se connecter'}
                </button>

                <p className="mt-4 text-center text-sm text-pacifique-navy-700/60">
                    Pas encore de dossier ?{' '}
                    <Link to="/inscription" className="font-medium text-pacifique-blue-600 hover:underline">
                        Faire une demande
                    </Link>
                </p>
            </form>
        </div>
    );
}