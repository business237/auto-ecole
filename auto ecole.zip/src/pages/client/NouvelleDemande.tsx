﻿import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Copy, ArrowLeft, Smartphone, Building2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useFormations, useInfosSite, reductionActive } from '@/lib/useSiteData';
import type { PaymentMethode } from '@/lib/database.types';

type Step = 'infos' | 'formation' | 'succes';

export default function NouvelleDemande() {
    const { formations = [] } = useFormations();
    const { infos } = useInfosSite();

    const [step, setStep] = useState<Step>('infos');
    const [nom, setNom] = useState('');
    const [prenom, setPrenom] = useState('');
    const [dateNaissance, setDateNaissance] = useState('');
    const [lieuNaissance, setLieuNaissance] = useState('');
    const [numeroCni, setNumeroCni] = useState('');
    const [dateDelivrance, setDateDelivrance] = useState('');
    const [telephone, setTelephone] = useState('');
    const [email, setEmail] = useState('');
    const [formationId, setFormationId] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);
    const [dossier, setDossier] = useState<string | null>(null);
    const [token, setToken] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    // Paiement
    const [payChoice, setPayChoice] = useState<'aucun' | 'maintenant' | 'plus_tard'>('aucun');
    const [methode, setMethode] = useState<PaymentMethode | ''>('');
    const [reference, setReference] = useState('');
    const [payError, setPayError] = useState<string | null>(null);
    const [payLoading, setPayLoading] = useState(false);
    const [paySent, setPaySent] = useState(false);

    const formationChoisie = formations.find((f) => f.id === formationId);
    const montant = formationChoisie
        ? reductionActive(formationChoisie)
            ? formationChoisie.prix_reduit
            : formationChoisie.prix
        : null;

    function handleNextStep(e: FormEvent) {
        e.preventDefault();
        setStep('formation');
    }

    async function handleSubmit(e: FormEvent) {
        e.preventDefault();
        if (!formationId) {
            setError('Sélectionnez une formation.');
            return;
        }
        setError(null);
        setSubmitting(true);

        const { data, error } = await supabase.rpc('creer_candidature', {
            p_nom: nom,
            p_prenom: prenom,
            p_date_naissance: dateNaissance || null,
            p_lieu_naissance: lieuNaissance || null,
            p_numero_cni: numeroCni || null,
            p_date_delivrance: dateDelivrance || null,
            p_telephone: telephone,
            p_email: email || null,
            p_formation_id: formationId,
        });

        setSubmitting(false);
        if (error || !data || data.length === 0) {
            setError('Une erreur est survenue. Réessayez.');
            return;
        }
        setDossier(data[0].numero_dossier);
        setToken(data[0].token_acces);
        setStep('succes');
    }

    async function handlePaySubmit(e: FormEvent) {
        e.preventDefault();
        if (!dossier || !methode) return;
        setPayError(null);
        setPayLoading(true);

        const { data, error } = await supabase.rpc('enregistrer_paiement', {
            p_telephone: telephone,
            p_numero_dossier: dossier,
            p_montant: montant,
            p_methode: methode,
            p_reference: reference || null,
        });

        setPayLoading(false);
        if (error || !data) {
            setPayError('Une erreur est survenue. Réessayez.');
            return;
        }
        setPaySent(true);
    }

    function copyDossier() {
        if (!dossier) return;
        navigator.clipboard.writeText(dossier);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    }

    // ===== ÉTAPE SUCCÈS =====
    if (step === 'succes' && dossier) {
        if (paySent) {
            return (
                <div className="mx-auto flex min-h-screen max-w-lg items-center bg-pacifique-offwhite px-4 py-16">
                    <div className="w-full rounded-2xl bg-white p-8 text-center shadow-sm">
                        <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-600" />
                        <h1 className="mt-4 text-xl font-semibold text-pacifique-navy-900">
                            Paiement en attente de confirmation
                        </h1>
                        <p className="mt-2 text-sm text-pacifique-navy-700/70">
                            Notre équipe va vérifier votre paiement et valider votre dossier {dossier}.
                        </p>
                        <Link
                            to={`/suivi/${encodeURIComponent(dossier)}?token=${encodeURIComponent(token ?? '')}`}
                            className="mt-6 inline-block rounded-lg bg-pacifique-navy-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-pacifique-navy-700"
                        >
                            Suivre mon dossier
                        </Link>
                    </div>
                </div>
            );
        }

        if (payChoice === 'maintenant') {
            return (
                <div className="mx-auto min-h-screen max-w-lg bg-pacifique-offwhite px-4 py-16">
                    <div className="rounded-2xl bg-white p-8 shadow-sm">
                        <button
                            onClick={() => setPayChoice('aucun')}
                            className="mb-4 flex items-center gap-1 text-sm text-pacifique-navy-700/60 hover:text-pacifique-navy-900"
                        >
                            <ArrowLeft size={14} /> Retour
                        </button>

                        <h1 className="mb-1 text-xl font-semibold text-pacifique-navy-900">Finaliser le paiement</h1>
                        <p className="mb-6 text-sm text-pacifique-navy-700/60">
                            Montant : <strong>{montant?.toLocaleString('fr-FR')} {formationChoisie?.devise}</strong>
                        </p>

                        <form onSubmit={handlePaySubmit} className="space-y-4">
                            <div className="space-y-2">
                                {(['mtn_momo', 'orange_money', 'sur_place'] as PaymentMethode[]).map((m) => (
                                    <label
                                        key={m}
                                        className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 ${methode === m ? 'border-pacifique-blue-500 bg-pacifique-blue-50/40' : 'border-gray-200'
                                            }`}
                                    >
                                        <input
                                            type="radio"
                                            name="methode"
                                            checked={methode === m}
                                            onChange={() => setMethode(m)}
                                            className="accent-pacifique-blue-600"
                                        />
                                        {m === 'sur_place' ? <Building2 size={18} /> : <Smartphone size={18} />}
                                        <span className="text-sm font-medium text-pacifique-navy-800">
                                            {m === 'mtn_momo' ? 'MTN Mobile Money' : m === 'orange_money' ? 'Orange Money' : "Paiement sur place"}
                                        </span>
                                    </label>
                                ))}
                            </div>

                            {methode === 'mtn_momo' && infos?.numero_momo && (
                                <p className="rounded-lg bg-pacifique-offwhite p-3 text-sm text-pacifique-navy-800">
                                    Envoyez le montant au <strong>{infos.numero_momo}</strong> puis indiquez la référence ci-dessous.
                                </p>
                            )}
                            {methode === 'orange_money' && infos?.numero_om && (
                                <p className="rounded-lg bg-pacifique-offwhite p-3 text-sm text-pacifique-navy-800">
                                    Envoyez le montant au <strong>{infos.numero_om}</strong> puis indiquez la référence ci-dessous.
                                </p>
                            )}
                            {methode === 'sur_place' && (
                                <p className="rounded-lg bg-pacifique-offwhite p-3 text-sm text-pacifique-navy-800">
                                    Vous pourrez régler directement à l'agence. Aucune référence n'est nécessaire.
                                </p>
                            )}

                            {(methode === 'mtn_momo' || methode === 'orange_money') && (
                                <div>
                                    <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">
                                        Référence de la transaction
                                    </label>
                                    <input
                                        value={reference}
                                        onChange={(e) => setReference(e.target.value)}
                                        required
                                        placeholder="Ex: MP240905.1234.A56789"
                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                                    />
                                </div>
                            )}

                            {payError && <p className="text-sm text-pacifique-red-500">{payError}</p>}

                            <button
                                type="submit"
                                disabled={!methode || payLoading}
                                className="w-full rounded-lg bg-pacifique-red-500 py-2.5 font-medium text-white hover:bg-pacifique-red-600 disabled:opacity-60"
                            >
                                {payLoading ? 'Envoi...' : "J'ai effectué le paiement"}
                            </button>
                        </form>
                    </div>
                </div>
            );
        }

        return (
            <div className="mx-auto flex min-h-screen max-w-lg items-center bg-pacifique-offwhite px-4 py-16">
                <div className="w-full rounded-2xl bg-white p-8 text-center shadow-sm">
                    <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-600" />
                    <h1 className="mt-4 text-xl font-semibold text-pacifique-navy-900">Demande enregistrée !</h1>
                    <p className="mt-2 text-sm text-pacifique-navy-700/70">Conservez précieusement ce numéro.</p>

                    <div className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-pacifique-offwhite px-4 py-4">
                        <span className="font-mono text-lg font-bold text-pacifique-navy-900">{dossier}</span>
                        <button onClick={copyDossier} className="rounded-lg p-2 text-pacifique-navy-700 hover:bg-white">
                            <Copy size={16} />
                        </button>
                    </div>
                    {copied && <p className="mt-2 text-xs text-emerald-600">Copié !</p>}

                    <Link
                        to={`/suivi/${encodeURIComponent(dossier)}?token=${encodeURIComponent(token ?? '')}`}
                        className="mt-4 block rounded-lg bg-pacifique-navy-900 py-3 text-sm font-bold text-white hover:bg-pacifique-navy-700"
                    >
                        Accéder à mon dossier
                    </Link>

                    <p className="mt-6 text-sm font-medium text-pacifique-navy-800">
                        Souhaitez-vous finaliser votre inscription maintenant ?
                    </p>
                    <div className="mt-3 flex flex-col gap-2">
                        <button
                            onClick={() => setPayChoice('maintenant')}
                            className="rounded-lg bg-pacifique-red-500 py-3 text-sm font-bold text-white hover:bg-pacifique-red-600"
                        >
                            💳 Payer maintenant
                        </button>
                        <Link
                            to="/suivre-ma-demande"
                            className="rounded-lg border border-gray-200 py-3 text-sm font-medium text-pacifique-navy-700 hover:bg-gray-50"
                        >
                            Plus tard
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    // ===== ÉTAPE 1 : INFOS =====
    if (step === 'infos') {
        return (
            <div className="mx-auto min-h-screen max-w-lg bg-pacifique-offwhite px-4 py-16">
                <div className="rounded-2xl bg-white p-8 shadow-sm">
                    <p className="mb-1 text-xs font-bold uppercase tracking-wide text-pacifique-blue-600">
                        Étape 1 / 2
                    </p>
                    <h1 className="mb-1 text-xl font-semibold text-pacifique-navy-900">Vos informations</h1>
                    <p className="mb-6 text-sm text-pacifique-navy-700/60">Aucun compte n'est nécessaire.</p>

                    <form onSubmit={handleNextStep} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <Field label="Nom" value={nom} onChange={setNom} required />
                            <Field label="Prénom" value={prenom} onChange={setPrenom} required />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">
                                    Date de naissance
                                </label>
                                <input
                                    type="date"
                                    value={dateNaissance}
                                    onChange={(e) => setDateNaissance(e.target.value)}
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                                />
                            </div>
                            <Field label="Lieu de naissance" value={lieuNaissance} onChange={setLieuNaissance} />
                        </div>

                        <Field label="Téléphone" value={telephone} onChange={setTelephone} required type="tel" placeholder="Ex: 6 99 00 00 00" />
                        <Field label="Email (facultatif)" value={email} onChange={setEmail} type="email" />

                        <div className="grid grid-cols-2 gap-4">
                            <Field label="Numéro CNI (optionnel)" value={numeroCni} onChange={setNumeroCni} />
                            <div>
                                <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">
                                    Date de délivrance (optionnel)
                                </label>
                                <input
                                    type="date"
                                    value={dateDelivrance}
                                    onChange={(e) => setDateDelivrance(e.target.value)}
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            className="w-full rounded-lg bg-pacifique-navy-900 py-2.5 font-medium text-white hover:bg-pacifique-navy-700"
                        >
                            Continuer →
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    // ===== ÉTAPE 2 : FORMATION =====
    return (
        <div className="mx-auto min-h-screen max-w-lg bg-pacifique-offwhite px-4 py-16">
            <div className="rounded-2xl bg-white p-8 shadow-sm">
                <button
                    onClick={() => setStep('infos')}
                    className="mb-4 flex items-center gap-1 text-sm text-pacifique-navy-700/60 hover:text-pacifique-navy-900"
                >
                    <ArrowLeft size={14} /> Retour
                </button>

                <p className="mb-1 text-xs font-bold uppercase tracking-wide text-pacifique-blue-600">
                    Étape 2 / 2
                </p>
                <h1 className="mb-6 text-xl font-semibold text-pacifique-navy-900">Votre formation</h1>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">
                            Formation souhaitée
                        </label>
                        <select
                            value={formationId}
                            onChange={(e) => setFormationId(e.target.value)}
                            required
                            className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                        >
                            <option value="">Sélectionnez une formation</option>
                            {formations.map((f) => (
                                <option key={f.id} value={f.id}>{f.titre}</option>
                            ))}
                        </select>
                    </div>

                    {error && <p className="text-sm text-pacifique-red-500">{error}</p>}

                    <button
                        type="submit"
                        disabled={submitting}
                        className="w-full rounded-lg bg-pacifique-red-500 py-2.5 font-medium text-white hover:bg-pacifique-red-600 disabled:opacity-60"
                    >
                        {submitting ? 'Envoi...' : 'Envoyer ma demande'}
                    </button>
                </form>
            </div>
        </div>
    );
}

function Field({
    label, value, onChange, required, type = 'text', placeholder,
}: {
    label: string; value: string; onChange: (v: string) => void;
    required?: boolean; type?: string; placeholder?: string;
}) {
    return (
        <div>
            <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">{label}</label>
            <input
                type={type}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                required={required}
                placeholder={placeholder}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
            />
        </div>
    );
}