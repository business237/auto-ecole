import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Calendar, Check, CreditCard, GraduationCap } from 'lucide-react';
import { supabase } from '@/lib/supabase';

type Resultat = {
    numero_dossier: string;
    nom: string;
    prenom: string;
    statut: string;
    formation_titre: string | null;
    created_at: string;
    paiement_statut: string | null;
    paiement_reference: string | null;
};

const STATUT_LABELS: Record<string, { label: string; className: string }> = {
    nouveau: { label: 'Nouveau', className: 'bg-amber-100 text-amber-700' },
    a_verifier: { label: 'À vérifier', className: 'bg-orange-100 text-orange-700' },
    incomplet: { label: 'Dossier incomplet', className: 'bg-orange-100 text-orange-700' },
    valide: { label: 'Dossier validé', className: 'bg-blue-100 text-blue-700' },
    formation_en_cours: { label: 'Formation en cours', className: 'bg-indigo-100 text-indigo-700' },
    termine: { label: 'Formation terminée', className: 'bg-emerald-100 text-emerald-700' },
    refuse: { label: 'Refusée', className: 'bg-gray-100 text-gray-600' },
};

const ETAPES = ['Demande reçue', 'Informations', 'Paiement', 'Vérification', 'Formation', 'Terminé'];

function getCurrentStep(resultat: Resultat) {
    if (resultat.statut === 'termine') return 5;
    if (resultat.statut === 'formation_en_cours') return 4;
    if (resultat.paiement_statut === 'confirme') return 3;
    if (resultat.statut === 'valide') return 2;
    if (['a_verifier', 'incomplet'].includes(resultat.statut)) return 1;
    return 0;
}

function getPaymentLabel(status: string | null) {
    if (status === 'confirme') return 'Confirmé';
    if (status === 'rejete') return 'Rejeté';
    return status ? 'En attente' : 'Aucun paiement';
}

function getPaymentClassName(status: string | null) {
    if (status === 'confirme') return 'bg-emerald-100 text-emerald-700';
    if (status === 'rejete') return 'bg-pacifique-red-100 text-pacifique-red-600';
    return 'bg-amber-100 text-amber-700';
}

export default function SuiviDossier() {
    const { numeroDossier } = useParams<{ numeroDossier: string }>();
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token') ?? '';
    const [resultat, setResultat] = useState<Resultat | null>(null);
    const [loading, setLoading] = useState(true);
    const [notFound, setNotFound] = useState(false);

    useEffect(() => {
        let active = true;

        async function loadDossier() {
            setLoading(true);
            setNotFound(false);
            setResultat(null);

            const { data, error } = await supabase.rpc('suivre_dossier_par_token', {
                p_numero_dossier: numeroDossier ?? '',
                p_token: token,
            });

            if (!active) return;
            setLoading(false);

            if (error || !data || data.length === 0) {
                setNotFound(true);
                return;
            }

            setResultat(data[0] as Resultat);
        }

        loadDossier();

        return () => {
            active = false;
        };
    }, [numeroDossier, token]);

    if (loading) {
        return (
            <div className="mx-auto flex min-h-screen max-w-lg items-center justify-center bg-pacifique-offwhite px-4 py-16">
                <p className="text-sm text-pacifique-navy-700/60">Chargement de votre dossier...</p>
            </div>
        );
    }

    if (notFound || !resultat) {
        return (
            <div className="mx-auto flex min-h-screen max-w-lg items-center bg-pacifique-offwhite px-4 py-16">
                <div className="w-full rounded-2xl bg-white p-8 text-center shadow-sm">
                    <h1 className="text-xl font-semibold text-pacifique-navy-900">Lien invalide ou expiré</h1>
                    <p className="mt-2 text-sm text-pacifique-navy-700/60">
                        Ce lien ne permet pas d'accéder à un dossier. Vous pouvez effectuer une recherche avec votre téléphone.
                    </p>
                    <Link
                        to="/suivre-ma-demande"
                        className="mt-6 inline-block rounded-lg bg-pacifique-navy-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-pacifique-navy-700"
                    >
                        Rechercher mon dossier
                    </Link>
                </div>
            </div>
        );
    }

    const currentStep = getCurrentStep(resultat);
    const statusLabel = STATUT_LABELS[resultat.statut] ?? {
        label: resultat.statut,
        className: 'bg-gray-100 text-gray-600',
    };

    return (
        <div className="mx-auto min-h-screen max-w-lg bg-pacifique-offwhite px-4 py-16">
            <div className="rounded-2xl bg-white p-8 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                    <div>
                        <p className="text-sm text-pacifique-navy-700/60">Suivi de votre dossier</p>
                        <h1 className="mt-1 text-xl font-semibold text-pacifique-navy-900">
                            Bonjour {resultat.prenom} !
                        </h1>
                    </div>
                    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusLabel.className}`}>
                        {statusLabel.label}
                    </span>
                </div>

                <p className="mt-4 font-mono text-sm font-semibold text-pacifique-navy-700">
                    Dossier {resultat.numero_dossier}
                </p>

                <div className="mt-8">
                    <h2 className="text-sm font-semibold text-pacifique-navy-900">Progression</h2>
                    <div className="mt-4">
                        {ETAPES.map((etape, index) => {
                            const completed = index < currentStep;
                            const current = index === currentStep;

                            return (
                                <div key={etape} className="flex min-h-12 gap-3">
                                    <div className="flex flex-col items-center">
                                        <div
                                            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${completed || current
                                                ? 'bg-pacifique-blue-500 text-white'
                                                : 'border border-gray-200 bg-gray-50 text-gray-400'
                                                }`}
                                        >
                                            {completed ? <Check size={14} /> : index + 1}
                                        </div>
                                        {index < ETAPES.length - 1 && (
                                            <div className={`mt-1 h-full w-px ${completed ? 'bg-pacifique-blue-500' : 'bg-gray-200'}`} />
                                        )}
                                    </div>
                                    <p
                                        className={`pb-5 text-sm ${current
                                            ? 'font-semibold text-pacifique-navy-900'
                                            : completed
                                                ? 'text-pacifique-navy-700/80'
                                                : 'text-pacifique-navy-700/40'
                                            }`}
                                    >
                                        {etape}
                                    </p>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {resultat.formation_titre && (
                    <div className="mt-2 flex items-center gap-2 text-sm text-pacifique-navy-700/80">
                        <GraduationCap size={16} className="text-pacifique-blue-500" />
                        {resultat.formation_titre}
                    </div>
                )}

                <div className="mt-6 rounded-xl border border-gray-100 bg-pacifique-offwhite p-5">
                    <div className="flex items-center gap-2">
                        <CreditCard size={17} className="text-pacifique-blue-500" />
                        <h2 className="font-semibold text-pacifique-navy-900">Mon paiement</h2>
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-3 text-sm">
                        <span className="text-pacifique-navy-700/60">Statut</span>
                        <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${getPaymentClassName(resultat.paiement_statut)}`}>
                            {getPaymentLabel(resultat.paiement_statut)}
                        </span>
                    </div>
                    {resultat.paiement_reference && (
                        <div className="mt-2 flex items-center justify-between gap-3 text-sm">
                            <span className="text-pacifique-navy-700/60">Référence</span>
                            <span className="font-medium text-pacifique-navy-900">{resultat.paiement_reference}</span>
                        </div>
                    )}
                    {resultat.paiement_statut !== 'confirme' && (
                        <Link
                            to="/inscription"
                            className="mt-4 flex items-center justify-center gap-2 rounded-lg bg-pacifique-red-500 py-2.5 text-sm font-bold text-white hover:bg-pacifique-red-600"
                        >
                            Effectuer un paiement
                        </Link>
                    )}
                </div>

                <p className="mt-5 flex items-center gap-2 text-xs text-pacifique-navy-700/50">
                    <Calendar size={14} />
                    Demande déposée le {new Date(resultat.created_at).toLocaleDateString('fr-FR')}
                </p>
            </div>
        </div>
    );
}
