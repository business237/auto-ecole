import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/useAuth';

export default function MonProfil() {
    const { profile, refreshProfile, loading } = useAuth();
    const [nomComplet, setNomComplet] = useState(profile?.nom_complet ?? '');
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);
    const [error, setError] = useState<string | null>(null);

    if (loading) return null;

    async function handleSubmit(e: FormEvent) {
        e.preventDefault();
        setError(null);
        setSaving(true);

        const { data: userData } = await supabase.auth.getUser();
        if (!userData.user) {
            setSaving(false);
            return;
        }

        const { error } = await supabase
            .from('profiles')
            .update({ nom_complet: nomComplet.trim() || null })
            .eq('id', userData.user.id);

        setSaving(false);
        if (error) {
            setError('Une erreur est survenue. Réessayez.');
            return;
        }
        await refreshProfile();
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
    }

    return (
        <div className="mx-auto min-h-screen max-w-lg bg-pacifique-offwhite px-4 py-16">
            <div className="rounded-2xl bg-white p-8 shadow-sm">
                <h1 className="mb-1 text-xl font-semibold text-pacifique-navy-900">Mon profil</h1>
                <p className="mb-6 text-sm text-pacifique-navy-700/60">
                    Renseignez votre nom pour personnaliser votre espace (facultatif).
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="mb-1 block text-sm font-medium text-pacifique-navy-700">
                            Nom complet
                        </label>
                        <input
                            value={nomComplet}
                            onChange={(e) => setNomComplet(e.target.value)}
                            placeholder="Ex: Jean Dupont"
                            className="w-full rounded-lg border border-gray-300 px-3 py-2 outline-none focus:border-pacifique-blue-500"
                        />
                    </div>

                    {error && <p className="text-sm text-pacifique-red-500">{error}</p>}

                    <button
                        type="submit"
                        disabled={saving}
                        className="flex w-full items-center justify-center gap-2 rounded-lg bg-pacifique-navy-900 py-2.5 font-medium text-white hover:bg-pacifique-navy-700 disabled:opacity-60"
                    >
                        {saving ? 'Enregistrement...' : saved ? (<><CheckCircle2 size={16} /> Enregistré</>) : 'Enregistrer'}
                    </button>
                </form>

                <Link to="/mon-compte" className="mt-4 inline-block text-sm text-pacifique-blue-600 hover:underline">
                    ← Retour à mon compte
                </Link>
            </div>
        </div>
    );
}