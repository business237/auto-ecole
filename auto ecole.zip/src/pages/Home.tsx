import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Hero from '@/components/Hero';
import WhyPacifique from '@/components/WhyPacifique';
import FAQ from '@/components/FAQ';
import { SectionHeading } from '@/components/ui';
import { useReveal } from '@/lib/hooks';
import { useFormations } from '@/lib/useSiteData';
import PermisIcon, { getPermisCategory } from '@/components/ui/PermisIcon';

export default function Home() {
    const { ref, visible } = useReveal<HTMLDivElement>();
    const { formations = [], loading } = useFormations();

    return (
        <>
            <Hero />
            <WhyPacifique />

            <section className="bg-pacifique-offwhite py-20 lg:py-28">
                <div ref={ref} className="mx-auto max-w-7xl px-5 lg:px-8">
                    <div className={`reveal ${visible ? 'is-visible' : ''}`}>
                        <SectionHeading
                            eyebrow="Nos Permis"
                            title="Choisissez votre formation"
                            subtitle="Découvrez toutes nos catégories de permis et trouvez la formation qui correspond à vos besoins."
                            centered
                        />
                    </div>

                    {loading ? (
                        <div className="mt-16 flex justify-center">
                            <div className="h-8 w-8 animate-spin rounded-full border-4 border-pacifique-blue-600 border-t-transparent" />
                        </div>
                    ) : formations.length === 0 ? (
                        <p className="mt-16 text-center text-sm text-pacifique-navy-700/60">
                            Les formations seront bientôt disponibles.
                        </p>
                    ) : (
                        <div className={`mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`}>
                            {formations.map((f, idx) => {
                                const category = getPermisCategory(f.titre);
                                return (
                                    <div
                                        key={f.id}
                                        className={`reveal group relative flex flex-col items-center rounded-3xl border border-gray-200/80 bg-white p-8 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-pacifique-blue-600/8 ${visible ? 'is-visible' : ''}`}
                                        style={{ transitionDelay: `${idx * 80}ms` }}
                                    >
                                        {/* Icône du permis */}
                                        <div
                                            className={`flex h-16 w-16 items-center justify-center rounded-2xl shadow-md transition-transform duration-300 group-hover:scale-110 ${category.badgeBg} ${category.badgeText}`}
                                        >
                                            <PermisIcon titre={f.titre} className="h-8 w-8" size={32} />
                                        </div>

                                        {/* Badge catégorie */}
                                        <span className={`mt-4 rounded-full px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider ${category.badgeBg} ${category.badgeText}`}>
                                            {category.label.split('•')[0].trim()}
                                        </span>

                                        {/* Titre */}
                                        <h3 className="mt-3 text-center font-display text-base font-bold text-pacifique-navy-900 leading-snug">
                                            {f.titre}
                                        </h3>

                                        {/* Durée si disponible */}
                                        {f.duree && (
                                            <span className="mt-2 text-xs font-medium text-pacifique-navy-700/50 bg-gray-100 px-2.5 py-0.5 rounded-full">
                                                {f.duree}
                                            </span>
                                        )}

                                        {/* Bouton Détail */}
                                        <Link
                                            to="/formations"
                                            className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl border-2 border-pacifique-navy-900 py-2.5 text-xs font-bold text-pacifique-navy-900 transition-all duration-200 hover:bg-pacifique-navy-900 hover:text-white active:scale-[0.98]"
                                        >
                                            <span>Voir les détails</span>
                                            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                                        </Link>
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {/* CTA global vers la page formations */}
                    {!loading && formations.length > 0 && (
                        <div className={`reveal mt-12 flex justify-center ${visible ? 'is-visible' : ''}`}>
                            <Link
                                to="/formations"
                                className="inline-flex items-center gap-2 rounded-2xl bg-pacifique-navy-900 px-8 py-4 text-sm font-bold text-white shadow-lg shadow-pacifique-navy-900/20 transition-all hover:-translate-y-0.5 hover:bg-pacifique-blue-600 hover:shadow-pacifique-blue-600/30 active:scale-[0.98]"
                            >
                                Voir toutes les formations & tarifs
                                <ArrowRight className="h-4 w-4" />
                            </Link>
                        </div>
                    )}
                </div>
            </section>

            <FAQ />
        </>
    );
}