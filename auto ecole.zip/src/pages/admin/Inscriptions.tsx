import { useEffect, useState } from 'react';
import { IdCard, Phone, Calendar, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Inscription } from '@/lib/database.types';
import PermisIcon from '@/components/ui/PermisIcon';

type InscriptionAvecFormation = Inscription & { formation: { titre: string } | null };

const STATUTS: Inscription['statut'][] = [
    'en_attente', 'dossier_incomplet', 'valide', 'formation_en_cours', 'termine', 'refusee',
];

const STATUT_LABELS: Record<Inscription['statut'], string> = {
    en_attente: 'En attente',
    dossier_incomplet: 'Dossier incomplet',
    valide: 'Validé',
    formation_en_cours: 'Formation en cours',
    termine: 'Terminé',
    refusee: 'Refusée',
};

export default function Inscriptions() {
    const [inscriptions, setInscriptions] = useState<InscriptionAvecFormation[]>([]);
    const [loading, setLoading] = useState(true);
    const [filtre, setFiltre] = useState<Inscription['statut'] | 'tous'>('tous');

    async function load() {
        setLoading(true);
        const { data } = await supabase
            .from('inscriptions')
            .select('*, formation:formations(titre)')
            .order('created_at', { ascending: false });
        setInscriptions((data as InscriptionAvecFormation[]) ?? []);
        setLoading(false);
    }

    useEffect(() => {
        load();
    }, []);

    async function updateStatut(id: string, statut: Inscription['statut']) {
        await supabase.from('inscriptions').update({ statut }).eq('id', id);
        load();
    }

    const filtered = filtre === 'tous' ? inscriptions : inscriptions.filter((i) => i.statut === filtre);

    return (
        <div>
            <div className="mb-6 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-pacifique-navy-900">Demandes d'inscription</h2>
                <select
                    value={filtre}
                    onChange={(e) => setFiltre(e.target.value as Inscription['statut'] | 'tous')}
                    className="rounded-lg border px-3 py-2 text-sm"
                >
                    <option value="tous">Tous les statuts</option>
                    {STATUTS.map((s) => (
                        <option key={s} value={s}>{STATUT_LABELS[s]}</option>
                    ))}
                </select>
            </div>

            {loading ? (
                <p className="text-sm text-pacifique-navy-700/60">Chargement...</p>
            ) : filtered.length === 0 ? (
                <p className="text-sm text-pacifique-navy-700/60">Aucune demande.</p>
            ) : (
                <div className="space-y-3">
                    {filtered.map((ins) => (
                        <div key={ins.id} className="rounded-xl border bg-white p-4">
                            <div className="flex flex-wrap items-start justify-between gap-3">
                                <div>
                                    <div className="flex items-center gap-2">
                                        <h3 className="font-medium text-pacifique-navy-900">
                                            {ins.nom} {ins.prenom}
                                        </h3>
                                        <span className="rounded-md bg-pacifique-offwhite px-2 py-0.5 font-mono text-xs text-pacifique-navy-700/70">
                                            {ins.numero_dossier}
                                        </span>
                                    </div>

                                    <div className="mt-2 flex flex-col gap-1 text-sm text-pacifique-navy-700/70">
                                        <span className="flex items-center gap-1.5">
                                            <Phone size={14} className="flex-shrink-0 text-pacifique-navy-700/40" />
                                            {ins.telephone}
                                        </span>

                                        {(ins.date_naissance || ins.lieu_naissance) && (
                                            <span className="flex items-center gap-1.5">
                                                <MapPin size={14} className="flex-shrink-0 text-pacifique-navy-700/40" />
                                                Né(e) {ins.date_naissance && `le ${new Date(ins.date_naissance).toLocaleDateString('fr-FR')}`}
                                                {ins.lieu_naissance && ` à ${ins.lieu_naissance}`}
                                            </span>
                                        )}

                                        {ins.numero_cni && (
                                            <span className="flex items-center gap-1.5">
                                                <IdCard size={14} className="flex-shrink-0 text-pacifique-navy-700/40" />
                                                CNI {ins.numero_cni}
                                                {ins.date_delivrance && ` — délivrée le ${new Date(ins.date_delivrance).toLocaleDateString('fr-FR')}`}
                                            </span>
                                        )}

                                        <span className="flex items-center gap-1.5 font-medium text-pacifique-navy-800">
                                            <PermisIcon titre={ins.formation?.titre} size={14} className="h-3.5 w-3.5 flex-shrink-0 text-pacifique-blue-600" />
                                            {ins.formation?.titre ?? 'Formation non précisée'}
                                        </span>

                                        <span className="flex items-center gap-1.5 text-xs text-pacifique-navy-700/40">
                                            <Calendar size={12} className="flex-shrink-0" />
                                            Reçue le {new Date(ins.created_at).toLocaleDateString('fr-FR')}
                                        </span>
                                    </div>
                                </div>

                                <select
                                    value={ins.statut}
                                    onChange={(e) => updateStatut(ins.id, e.target.value as Inscription['statut'])}
                                    className="rounded-lg border px-3 py-2 text-sm"
                                >
                                    {STATUTS.map((s) => (
                                        <option key={s} value={s}>{STATUT_LABELS[s]}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}