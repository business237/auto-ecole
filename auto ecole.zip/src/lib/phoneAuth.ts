// Transforme un numéro de téléphone en "email technique" utilisé en interne
// par Supabase Auth. Le client ne voit jamais cet email — pour lui, l'identifiant
// est simplement son numéro de téléphone.
export function phoneToEmail(telephone: string): string {
    const digits = telephone.replace(/\D/g, '');
    return `tel${digits}@pacifique.local`;
}

export function normalizePhone(telephone: string): string {
    return telephone.replace(/\D/g, '');
}