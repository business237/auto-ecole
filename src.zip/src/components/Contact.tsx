import { useState, type FormEvent } from 'react';
import { Phone, MessageCircle, Send, CheckCircle2, MapPin, Clock, Mail } from 'lucide-react';
import { SectionHeading } from '@/components/ui';
import { SITE, telLink, whatsappLink } from '@/lib/site';
import { useReveal } from '@/lib/hooks';

export default function Contact() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    formation: 'Permis B (Complet)',
    message: '',
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    // Pre-fill WhatsApp message
    const msg = `Bonjour Auto-École Pacifique,\nJe m'appelle ${formData.fullName}.\nTéléphone: ${formData.phone}\nFormation souhaitée: ${formData.formation}\nMessage: ${formData.message || 'Aucun message supplémentaire.'}`;
    window.open(whatsappLink(msg), '_blank');
    setSubmitted(true);
  }

  return (
    <section id="contact" className="bg-white py-20 lg:py-28 relative">
      <div ref={ref} className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className={`reveal ${visible ? 'is-visible' : ''}`}>
          <SectionHeading
            eyebrow="Inscription & Contact"
            title="Prenez le volant dès aujourd'hui"
            subtitle="Remplissez le formulaire ci-dessous ou contactez-nous directement via WhatsApp ou téléphone pour vous inscrire."
            centered
          />
        </div>

        <div className="mt-16 grid gap-12 lg:grid-cols-12 lg:items-start">
          {/* Info Card - 5 cols */}
          <div className={`reveal lg:col-span-5 rounded-3xl bg-gradient-to-br from-pacifique-navy-950 via-pacifique-navy-900 to-pacifique-navy-800 p-8 text-white shadow-xl ${visible ? 'is-visible' : ''}`}>
            <h3 className="font-display text-2xl font-bold">Informations Pratiques</h3>
            <p className="mt-3 text-xs leading-relaxed text-pacifique-blue-100/75">
              Notre équipe d'accueil vous reçoit du Lundi au Samedi pour enregistrer votre inscription et répondre à vos questions.
            </p>

            <div className="mt-8 space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-pacifique-blue-500/20 text-pacifique-blue-400">
                  <MapPin className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-pacifique-blue-300">Adresse</h4>
                  <p className="mt-1 text-sm text-white font-medium">{SITE.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-pacifique-blue-500/20 text-pacifique-blue-400">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-pacifique-blue-300">Téléphone</h4>
                  <a href={telLink} className="mt-1 block text-sm font-semibold text-white hover:text-pacifique-blue-300 transition-colors">
                    {SITE.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-pacifique-blue-500/20 text-pacifique-blue-400">
                  <Mail className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-pacifique-blue-300">Email</h4>
                  <p className="mt-1 text-sm text-white font-medium">{SITE.email}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-pacifique-blue-500/20 text-pacifique-blue-400">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-pacifique-blue-300">Horaires de cours</h4>
                  <p className="mt-1 text-xs text-pacifique-blue-100/80">Lundi – Samedi : 08h00 – 18h00</p>
                  <p className="text-[11px] text-pacifique-blue-200/60">Sessions théoriques & créneaux de conduite personnalisés</p>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-6 border-t border-white/10 flex flex-col gap-3">
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2.5 rounded-full bg-[#25D366] px-5 py-3 text-xs font-bold text-white shadow-lg transition-transform active:scale-95 hover:bg-[#20ba5a]"
              >
                <MessageCircle className="h-4 w-4" />
                Discuter directement sur WhatsApp
              </a>
            </div>
          </div>

          {/* Registration Form - 7 cols */}
          <div className={`reveal lg:col-span-7 rounded-3xl bg-pacifique-offwhite p-8 lg:p-10 border border-gray-100 ${visible ? 'is-visible' : ''}`} style={{ transitionDelay: '150ms' }}>
            <h3 className="font-display text-2xl font-bold text-pacifique-navy-900">Formulaire de pré-inscription</h3>
            <p className="mt-2 text-xs text-pacifique-navy-700/70">
              Remplissez ces informations. Vous serez directement redirigé(e) vers WhatsApp pour finaliser votre demande.
            </p>

            {submitted ? (
              <div className="mt-8 rounded-2xl bg-emerald-50 border border-emerald-200 p-6 text-center">
                <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
                <h4 className="mt-3 font-display text-lg font-bold text-emerald-900">Demande envoyée avec succès !</h4>
                <p className="mt-1 text-xs text-emerald-700">
                  Votre demande d'information s'est ouverte sur WhatsApp. Si la fenêtre ne s'est pas ouverte automatiquement, cliquez sur le bouton ci-dessous.
                </p>
                <button
                  type="button"
                  onClick={() => setSubmitted(false)}
                  className="mt-5 rounded-full bg-emerald-600 px-5 py-2 text-xs font-bold text-white hover:bg-emerald-700 transition"
                >
                  Envoyer une autre demande
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="mt-8 space-y-5">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-pacifique-navy-800">
                    Nom complet <span className="text-pacifique-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Jean Dupont"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-pacifique-navy-900 placeholder:text-gray-400 focus:border-pacifique-blue-500 focus:outline-none focus:ring-2 focus:ring-pacifique-blue-500/20 transition"
                  />
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-pacifique-navy-800">
                      Téléphone / WhatsApp <span className="text-pacifique-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="Ex: 6 99 00 00 00"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-pacifique-navy-900 placeholder:text-gray-400 focus:border-pacifique-blue-500 focus:outline-none focus:ring-2 focus:ring-pacifique-blue-500/20 transition"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-pacifique-navy-800">
                      Email (Optionnel)
                    </label>
                    <input
                      type="email"
                      placeholder="votre.email@exemple.cm"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-pacifique-navy-900 placeholder:text-gray-400 focus:border-pacifique-blue-500 focus:outline-none focus:ring-2 focus:ring-pacifique-blue-500/20 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-pacifique-navy-800">
                    Formation souhaitée
                  </label>
                  <select
                    value={formData.formation}
                    onChange={(e) => setFormData({ ...formData, formation: e.target.value })}
                    className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-pacifique-navy-900 focus:border-pacifique-blue-500 focus:outline-none focus:ring-2 focus:ring-pacifique-blue-500/20 transition"
                  >
                    <option value="Permis B (Complet)">Permis B (Complet)</option>
                    <option value="Cours de Code Bilingue">Cours de Code Bilingue</option>
                    <option value="Conduite Accélérée">Conduite Accélérée / Stage Intensif</option>
                    <option value="Perfectionnement">Recyclage / Perfectionnement</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-pacifique-navy-800">
                    Votre message ou questions
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Précisez vos disponibilités ou toute question particulière..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-pacifique-navy-900 placeholder:text-gray-400 focus:border-pacifique-blue-500 focus:outline-none focus:ring-2 focus:ring-pacifique-blue-500/20 transition"
                  />
                </div>

                <button
                  type="submit"
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-pacifique-red-500 px-6 py-4 text-sm font-bold text-white shadow-xl shadow-pacifique-red-500/25 transition-all hover:bg-pacifique-red-600 hover:shadow-pacifique-red-500/40 active:scale-98"
                >
                  <Send className="h-4 w-4" />
                  Envoyer ma pré-inscription sur WhatsApp
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
