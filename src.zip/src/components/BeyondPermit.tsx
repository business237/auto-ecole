import { ShieldCheck, HeartHandshake, Leaf, Compass } from 'lucide-react';
import { SectionHeading } from '@/components/ui';
import { useReveal } from '@/lib/hooks';

const PILLARS = [
  {
    icon: ShieldCheck,
    title: 'Conduite Préventive',
    desc: 'Anticiper les comportements des autres usagers et réagir sereinement face aux imprévus.',
  },
  {
    icon: HeartHandshake,
    title: 'Civisme & Respect',
    desc: 'Promouvoir la courtoisie au volant et le respect absolu des piétons et cyclistes.',
  },
  {
    icon: Leaf,
    title: 'Éco-conduite',
    desc: 'Adopter une conduite fluide réduisant la consommation de carburant et l’usure du véhicule.',
  },
  {
    icon: Compass,
    title: 'Maîtrise & Sang-froid',
    desc: 'Gérer la fatigue, le stress et les conditions météo difficiles avec assurance.',
  },
];

export default function BeyondPermit() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section className="bg-pacifique-navy-950 text-white py-20 lg:py-28 relative overflow-hidden">
      {/* Background glow effects */}
      <div className="pointer-events-none absolute -left-40 top-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-pacifique-blue-600/10 blur-3xl" />
      <div className="pointer-events-none absolute -right-40 top-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-pacifique-red-500/10 blur-3xl" />

      <div ref={ref} className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className={`reveal ${visible ? 'is-visible' : ''}`}>
          <SectionHeading
            eyebrow="Au-delà du permis"
            title="Former des conducteurs responsables pour la vie"
            subtitle="Obtenir le permis de conduire n'est qu'une étape. Notre ambition ultime est de vous donner les réflexes indispensables pour préserver votre vie et celle d'autrui."
            centered
            light
          />
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((p, idx) => {
            const Icon = p.icon;
            return (
              <div
                key={p.title}
                className={`reveal rounded-3xl border border-white/10 bg-white/5 p-8 backdrop-blur-sm transition-all duration-300 hover:border-pacifique-blue-400/40 hover:bg-white/10 ${
                  visible ? 'is-visible' : ''
                }`}
                style={{ transitionDelay: `${idx * 120}ms` }}
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-pacifique-blue-500/20 text-pacifique-blue-400">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-6 font-display text-lg font-bold text-white">{p.title}</h3>
                <p className="mt-3 text-xs leading-relaxed text-pacifique-blue-100/70">{p.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Highlight quote banner */}
        <div className={`reveal mt-16 rounded-3xl bg-gradient-to-r from-pacifique-navy-900 via-pacifique-navy-800 to-pacifique-navy-900 p-8 border border-white/10 text-center ${visible ? 'is-visible' : ''}`} style={{ transitionDelay: '500ms' }}>
          <p className="font-display text-lg font-bold text-white sm:text-xl">
            « La sécurité routière commence par la prise de conscience de chaque conducteur au volant. »
          </p>
          <p className="mt-2 text-xs font-semibold text-pacifique-blue-300">
            Auto-École Pacifique Bilingue — Kribi
          </p>
        </div>
      </div>
    </section>
  );
}
