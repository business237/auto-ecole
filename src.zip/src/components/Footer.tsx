import { Facebook, Instagram, Phone, MapPin, MessageCircle } from 'lucide-react';
import { SITE, telLink, whatsappLink } from '@/lib/site';

// TikTok icon — lucide doesn't ship one, so we use a small inline SVG
function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.73 2.89 2.89 0 0 1 2.31-4.64c.3 0 .6.05.88.13V9.4a6.33 6.33 0 0 0-1-.05A6.34 6.34 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43V8.69a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.12z" />
    </svg>
  );
}

const NAV = [
  { href: '#accueil', label: 'Accueil' },
  { href: '#apropos', label: 'À propos' },
  { href: '#formations', label: 'Formations' },
  { href: '#galerie', label: 'Galerie' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contact' },
];

export default function Footer() {
  const socials = [
    { href: SITE.social.facebook || '#', label: 'Facebook', icon: Facebook, available: !!SITE.social.facebook },
    { href: SITE.social.instagram || '#', label: 'Instagram', icon: Instagram, available: !!SITE.social.instagram },
    { href: SITE.social.tiktok || '#', label: 'TikTok', icon: TikTokIcon, available: !!SITE.social.tiktok },
    { href: whatsappLink(), label: 'WhatsApp', icon: MessageCircle, available: true },
  ];

  return (
    <footer className="bg-pacifique-navy-950 text-white">
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-pacifique-blue-500/15">
                <svg viewBox="0 0 32 32" className="h-6 w-6" fill="none" aria-hidden="true">
                  <circle cx="16" cy="16" r="12" stroke="#2b80ed" strokeWidth="2.5" />
                  <circle cx="16" cy="16" r="3" fill="#e83333" />
                  <path d="M16 5v4M16 23v4M5 16h4M23 16h4" stroke="#2b80ed" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </span>
              <div className="leading-none">
                <p className="font-display text-lg font-extrabold">PACIFIQUE</p>
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-pacifique-blue-300">Auto-École Bilingue</p>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-pacifique-blue-100/60">
              Formation à la conduite et sensibilisation à la sécurité routière à Kribi.
            </p>

            {/* Social */}
            <div className="mt-5 flex gap-2.5">
              {socials.map((s) =>
                s.available ? (
                  <a
                    key={s.label}
                    href={s.href}
                    target={s.label === 'WhatsApp' ? '_blank' : undefined}
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 text-pacifique-blue-200 transition-colors hover:bg-pacifique-blue-500 hover:text-white"
                  >
                    <s.icon className="h-4 w-4" />
                  </a>
                ) : (
                  <span
                    key={s.label}
                    aria-label={`${s.label} — bientôt disponible`}
                    className="flex h-9 w-9 cursor-default items-center justify-center rounded-lg bg-white/5 text-white/20"
                  >
                    <s.icon className="h-4 w-4" />
                  </span>
                )
              )}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-white">Navigation</h4>
            <ul className="mt-4 space-y-2.5">
              {NAV.map((n) => (
                <li key={n.href}>
                  <a href={n.href} className="text-sm text-pacifique-blue-100/60 transition-colors hover:text-pacifique-blue-400">{n.label}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-white">Contact</h4>
            <ul className="mt-4 space-y-3">
              <li className="flex items-start gap-3 text-sm text-pacifique-blue-100/60">
                <MapPin className="h-4 w-4 flex-shrink-0 text-pacifique-blue-400" />
                <span>Kribi — Dombe</span>
              </li>
              <li>
                <a href={telLink} className="flex items-center gap-3 text-sm text-pacifique-blue-100/60 transition-colors hover:text-pacifique-blue-400">
                  <Phone className="h-4 w-4 flex-shrink-0 text-pacifique-blue-400" />
                  {SITE.phone}
                </a>
              </li>
            </ul>
          </div>

          {/* AFJANES Group */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-white">AFJANES Group</h4>
            <p className="mt-4 text-sm leading-relaxed text-pacifique-blue-100/60">
              Auto-École Pacifique est une entité d'AFJANES GROUP.
            </p>
            <div className="mt-4 rounded-xl bg-white/5 px-4 py-3">
              <p className="font-display text-sm font-bold text-white">{SITE.group}</p>
              <p className="mt-1 text-xs text-pacifique-blue-200/50">Écosystème de formation à la conduite</p>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 border-t border-white/10 pt-6">
          <p className="text-center text-xs text-pacifique-blue-100/40">
            © 2026 Auto-École Pacifique — Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}
