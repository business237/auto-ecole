import { useEffect, useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { SectionHeading } from '@/components/ui';
import { useReveal } from '@/lib/hooks';

interface GalleryImage {
  src: string;
  alt: string;
  span?: 'wide' | 'tall';
}

const IMAGES: GalleryImage[] = [
  {
    src: 'https://images.pexels.com/photos/9518244/pexels-photo-9518244.jpeg?auto=compress&cs=tinysrgb&w=900',
    alt: "Moniteur accompagnant un élève au volant lors d'une leçon de conduite",
    span: 'wide',
  },
  {
    src: 'https://images.pexels.com/photos/19477337/pexels-photo-19477337.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: "Mains d'un conducteur sur le volant",
  },
  {
    src: 'https://images.pexels.com/photos/8673763/pexels-photo-8673763.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Panneau de signalisation routière sur une route',
  },
  {
    src: 'https://images.pexels.com/photos/13811143/pexels-photo-13811143.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Conducteur au volant dans une circulation urbaine',
  },
  {
    src: 'https://images.pexels.com/photos/6333638/pexels-photo-6333638.jpeg?auto=compress&cs=tinysrgb&w=900',
    alt: 'Route urbaine avec végétation — illustration de la conduite en milieu réel',
    span: 'wide',
  },
  {
    src: 'https://images.pexels.com/photos/33610625/pexels-photo-33610625.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Voiture sur une route côtière bordée de palmiers',
  },
  {
    src: 'https://images.pexels.com/photos/17164787/pexels-photo-17164787.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: "Jeune conductrice concentrée au volant",
  },
  {
    src: 'https://images.pexels.com/photos/33177740/pexels-photo-33177740.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Volant de voiture en gros plan',
  },
];

export default function Gallery() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [lightbox, setLightbox] = useState<number | null>(null);

  const close = () => setLightbox(null);
  const prev = () => setLightbox((i) => (i === null ? null : (i - 1 + IMAGES.length) % IMAGES.length));
  const next = () => setLightbox((i) => (i === null ? null : (i + 1) % IMAGES.length));

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') prev();
      if (e.key === 'ArrowRight') next();
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [lightbox]);

  return (
    <section id="galerie" className="bg-white py-20 lg:py-28">
      <div ref={ref} className="mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHeading
          eyebrow="Galerie"
          title="La conduite en images."
          subtitle="Visuels d'illustration de l'apprentissage de la conduite et de la sécurité routière. Les photos seront remplacées par celles de Pacifique dès qu'elles seront disponibles."
          centered
        />

        <div className="mt-14 grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4">
          {IMAGES.map((img, i) => (
            <button
              key={img.src}
              type="button"
              onClick={() => setLightbox(i)}
              className={`reveal group relative overflow-hidden rounded-2xl shadow-sm transition-all duration-500 hover:shadow-xl hover:shadow-pacifique-navy-900/10 ${
                visible ? 'is-visible' : ''
              } ${
                img.span === 'wide'
                  ? 'col-span-2 aspect-[16/10] lg:row-span-1'
                  : 'aspect-square'
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
              aria-label={`Ouvrir l'image : ${img.alt}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-pacifique-navy-950/50 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <div className="absolute bottom-3 left-3 right-3 translate-y-2 text-left text-xs font-medium text-white opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                {img.alt}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-pacifique-navy-950/90 p-4 backdrop-blur-sm"
          onClick={close}
          role="dialog"
          aria-modal="true"
          aria-label="Visionneuse d'images"
        >
          <button
            type="button"
            onClick={close}
            className="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            aria-label="Fermer"
          >
            <X className="h-6 w-6" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); prev(); }}
            className="absolute left-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20 sm:left-6"
            aria-label="Image précédente"
          >
            <ChevronLeft className="h-7 w-7" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); next(); }}
            className="absolute right-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20 sm:right-6"
            aria-label="Image suivante"
          >
            <ChevronRight className="h-7 w-7" />
          </button>
          <figure className="max-h-[85vh] max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <img
              src={IMAGES[lightbox].src}
              alt={IMAGES[lightbox].alt}
              className="max-h-[78vh] w-auto rounded-xl object-contain"
            />
            <figcaption className="mt-3 text-center text-sm text-white/70">{IMAGES[lightbox].alt}</figcaption>
          </figure>
        </div>
      )}
    </section>
  );
}
