import { Check, Sparkles, BookOpen, Car, Zap, RefreshCw } from 'lucide-react';
import { SectionHeading } from '@/components/ui';
import { whatsappLink } from '@/lib/site';
import { useReveal } from '@/lib/hooks';

const FORMATIONS = [
  {
    id: 'permis-b',
    name: 'Permis B (Complet)',
    badge: 'Le plus populaire',
    popular: true,
    icon: Car,
    description: 'La formation complète théorique et pratique pour la conduite de véhicules légers.',
    features: [
      'Cours théoriques du Code de la Route bilingue',
      'Leçons de conduite pratique personnalisées',
      'Supports de cours & entraînement aux tests',
      'Présentation aux examens officiels',
      'Accompagnement et suivi individuel',
    ],
  },
  {
    id: 'code-bilingue',
    name: 'Cours de Code Bilingue',
    badge: 'Théorie seule',
    popular: false,
    icon: BookOpen,
    description: 'Une préparation théorique approfondie en Français et Anglais pour maîtriser le code de la route.',
    features: [
      'Salles de cours aménagées et confortables',
      'Enseignement en Français et English',
      'Examens blancs hebdomadaires',
      'Apprentissage de la signalisation routière',
      'Sensibilisation aux premiers secours routiers',
    ],
  },
  {
    id: 'stage-intensif',
    name: 'Conduite Accélérée',
    badge: 'Express',
    popular: false,
    icon: Zap,
    description: 'Formation rapide et condensée pour les apprenants disposant de peu de temps libre.',
    features: [
      'Planning intensif personnalisé',
      'Sessions quotidiennes théorie + pratique',
      'Révision accélérée des notions clés',
      'Priorité de réservation des créneaux',
      'Préparation mentale à l’examen',
    ],
  },
  {
    id: 'perfectionnement',
    name: 'Perfectionnement',
    badge: 'Conducteurs titulaires',
    popular: false,
    icon: RefreshCw,
    description: 'Pour les titulaires du permis souhaitant reprendre confiance ou perfectionner leur conduite.',
    features: [
      'Remise à niveau sur autoroute & ville',
      'Conduite de nuit et par temps de pluie',
      'Gestion des créneaux et stationnements',
      'Conduite défensive et éco-conduite',
      'Évaluation personnalisée de votre conduite',
    ],
  },
];

export default function Formation() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="formations" className="bg-white py-20 lg:py-28">
      <div ref={ref} className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className={`reveal ${visible ? 'is-visible' : ''}`}>
          <SectionHeading
            eyebrow="Nos Formations"
            title="Des formules adaptées à tous vos besoins"
            subtitle="Découvrez nos programmes d'apprentissage conçus pour vous mener au succès avec sérénité."
            centered
          />
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {FORMATIONS.map((f, idx) => {
            const Icon = f.icon;
            return (
              <div
                key={f.id}
                className={`reveal relative flex flex-col justify-between rounded-3xl border ${
                  f.popular
                    ? 'border-pacifique-blue-500 bg-gradient-to-b from-pacifique-blue-50/40 to-white shadow-xl shadow-pacifique-blue-500/10'
                    : 'border-gray-200/80 bg-white shadow-sm hover:shadow-lg'
                } p-7 transition-all duration-300 ${visible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                {f.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 inline-flex items-center gap-1.5 rounded-full bg-pacifique-blue-600 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white shadow-md">
                    <Sparkles className="h-3 w-3" />
                    {f.badge}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between">
                    <div
                      className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                        f.popular
                          ? 'bg-pacifique-blue-600 text-white'
                          : 'bg-pacifique-offwhite text-pacifique-navy-900'
                      }`}
                    >
                      <Icon className="h-6 w-6" />
                    </div>
                    {!f.popular && (
                      <span className="text-xs font-semibold text-pacifique-navy-700/60 bg-gray-100 px-2.5 py-1 rounded-full">
                        {f.badge}
                      </span>
                    )}
                  </div>

                  <h3 className="mt-5 font-display text-xl font-bold text-pacifique-navy-900">
                    {f.name}
                  </h3>
                  <p className="mt-2 text-xs leading-relaxed text-pacifique-navy-700/70">
                    {f.description}
                  </p>

                  <ul className="mt-6 space-y-3">
                    {f.features.map((feat) => (
                      <li key={feat} className="flex items-start gap-2.5 text-xs text-pacifique-navy-800">
                        <Check className="h-4 w-4 flex-shrink-0 text-pacifique-blue-600 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 pt-4 border-t border-gray-100">
                  <a
                    href={whatsappLink(`Bonjour, je souhaite obtenir plus d'informations sur la formation : ${f.name}`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex w-full items-center justify-center rounded-xl py-3 text-xs font-bold transition-all duration-200 ${
                      f.popular
                        ? 'bg-pacifique-red-500 text-white hover:bg-pacifique-red-600 shadow-md shadow-pacifique-red-500/20'
                        : 'bg-pacifique-navy-900 text-white hover:bg-pacifique-navy-800'
                    }`}
                  >
                    S'informer / S'inscrire
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
