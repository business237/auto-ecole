import { MapPin, Navigation, Anchor, Sun } from 'lucide-react';
import { SectionHeading } from '@/components/ui';
import { SITE, whatsappLink } from '@/lib/site';
import { useReveal } from '@/lib/hooks';

export default function KribiSection() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section className="bg-gradient-to-b from-pacifique-offwhite via-white to-pacifique-offwhite py-20 lg:py-28 relative overflow-hidden">
      <div ref={ref} className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          {/* Content */}
          <div className={`reveal ${visible ? 'is-visible' : ''}`}>
            <SectionHeading
              eyebrow="Kribi & Notre Implantation"
              title="Ancrée au cœur de la cité balnéaire de Kribi"
              subtitle="Implantée au quartier Dombe, Auto-École Pacifique offre une formation de proximité pensée spécifiquement pour les enjeux routiers de Kribi et sa région."
            />

            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl bg-white p-5 border border-gray-100 shadow-sm">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-pacifique-blue-50 text-pacifique-blue-600">
                  <Anchor className="h-5 w-5" />
                </div>
                <h4 className="mt-3 font-display text-sm font-bold text-pacifique-navy-900">Axe Portuaire & Urbain</h4>
                <p className="mt-1 text-xs text-pacifique-navy-700/70">
                  Apprentissage de la cohabitation avec le trafic lourd et la circulation urbaine de Kribi.
                </p>
              </div>

              <div className="rounded-2xl bg-white p-5 border border-gray-100 shadow-sm">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-pacifique-red-50 text-pacifique-red-500">
                  <Sun className="h-5 w-5" />
                </div>
                <h4 className="mt-3 font-display text-sm font-bold text-pacifique-navy-900">Conditions Tropicales</h4>
                <p className="mt-1 text-xs text-pacifique-navy-700/70">
                  Conduite sous fortes pluies côtières et sur chaussée glissante pour une sécurité optimale.
                </p>
              </div>
            </div>

            <div className="mt-8 flex items-center gap-3">
              <MapPin className="h-5 w-5 text-pacifique-red-500 flex-shrink-0" />
              <span className="text-sm font-semibold text-pacifique-navy-900">
                {SITE.address}
              </span>
            </div>

            <div className="mt-8">
              <a
                href={whatsappLink('Bonjour, je souhaite connaître l’emplacement exact et les horaires d’ouverture de l’agence Dombe.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-pacifique-navy-900 px-6 py-3 text-sm font-bold text-white transition-all hover:bg-pacifique-navy-800 active:scale-95 shadow-md"
              >
                <Navigation className="h-4 w-4" />
                Localiser notre agence à Dombe
              </a>
            </div>
          </div>

          {/* Visual Showcase */}
          <div className={`reveal relative ${visible ? 'is-visible' : ''}`} style={{ transitionDelay: '200ms' }}>
            <div className="relative aspect-[4/3] overflow-hidden rounded-3xl shadow-2xl shadow-pacifique-navy-900/15">
              <img
                src="https://images.pexels.com/photos/1544372/pexels-photo-1544372.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Paysage de Kribi et route côtière"
                className="h-full w-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-pacifique-navy-950/60 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="inline-block rounded-full bg-pacifique-red-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider">
                  Dombe • Kribi
                </span>
                <p className="mt-2 font-display text-lg font-bold">
                  Apprenez à conduire en toute sécurité sur les routes du Sud.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
