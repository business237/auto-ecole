export interface Formation {
    id: string;
    titre: string;
    description: string | null;
    prix: number | null;
    devise: string;
    duree: string | null;
    inclus: string[] | null;
    ordre: number;
    actif: boolean;
    created_at: string;
    updated_at: string;
}

export interface GalerieImage {
    id: string;
    url: string;
    alt: string | null;
    ordre: number;
    created_at: string;
}

export interface InfosSite {
    id: number;
    adresse: string | null;
    telephone: string | null;
    whatsapp: string | null;
    email: string | null;
    horaires: Record<string, string> | null;
    facebook: string | null;
    instagram: string | null;
    tiktok: string | null;
}