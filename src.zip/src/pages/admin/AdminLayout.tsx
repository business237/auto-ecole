import { NavLink, Outlet } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const TABS = [
    { to: '/admin/formations', label: 'Formations' },
    { to: '/admin/galerie', label: 'Galerie' },
    { to: '/admin/infos', label: 'Infos pratiques' },
];

export default function AdminLayout() {
    async function handleLogout() {
        await supabase.auth.signOut();
    }

    return (
        <div className="min-h-screen bg-pacifique-offwhite">
            <header className="flex items-center justify-between border-b bg-white px-6 py-4">
                <h1 className="font-semibold text-pacifique-navy-900">
                    Pacifique — Administration
                </h1>
                <button
                    onClick={handleLogout}
                    className="flex items-center gap-1.5 text-sm text-pacifique-navy-700 hover:text-pacifique-red-500"
                >
                    <LogOut size={16} /> Déconnexion
                </button>
            </header>

            <nav className="flex gap-1 border-b bg-white px-6">
                {TABS.map((tab) => (
                    <NavLink
                        key={tab.to}
                        to={tab.to}
                        className={({ isActive }) =>
                            `border-b-2 px-4 py-3 text-sm font-medium transition ${isActive
                                ? 'border-pacifique-red-500 text-pacifique-navy-900'
                                : 'border-transparent text-pacifique-navy-700/60 hover:text-pacifique-navy-900'
                            }`
                        }
                    >
                        {tab.label}
                    </NavLink>
                ))}
            </nav>

            <main className="mx-auto max-w-5xl px-6 py-8">
                <Outlet />
            </main>
        </div>
    );
}