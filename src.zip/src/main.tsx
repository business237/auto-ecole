import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App.tsx';
import Login from './pages/admin/Login.tsx';
import ProtectedRoute from './pages/admin/ProtectedRoute.tsx';
import AdminLayout from './pages/admin/AdminLayout.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/admin/login" element={<Login />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          {/* les sous-pages Formations/Galerie/Infos arrivent à l'étape suivante */}
        </Route>
      </Routes>
    </BrowserRouter>
  </StrictMode>
);