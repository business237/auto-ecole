import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import WhyPacifique from '@/components/WhyPacifique';
import Formation from '@/components/Formation';
import BeyondPermit from '@/components/BeyondPermit';
import About from '@/components/About';
import Approach from '@/components/Approach';
import Gallery from '@/components/Gallery';
import KribiSection from '@/components/KribiSection';
import Contact from '@/components/Contact';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';
import { ScrollProgress } from '@/components/ui';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <WhyPacifique />
        <Formation />
        <BeyondPermit />
        <About />
        <Approach />
        <Gallery />
        <KribiSection />
        <Contact />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}

export default App;
